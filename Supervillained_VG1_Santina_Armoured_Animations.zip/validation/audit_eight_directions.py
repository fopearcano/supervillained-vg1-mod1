"""Independently inspect saved Santina atlas pixels, optionally inside a final ZIP.

Hashes are calculated from visible RGBA pixels with hidden RGB cleared; cropped
hashes also catch direction aliases differing only by position. Pixel checks do
not establish semantic body yaw: inspect the eight-view contact sheet separately.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from PIL import Image

DIRS = ('N','NE','E','SE','S','SW','W','NW')
ACTION_CODES = {'idle':'B','walk':'C','run':'D','sniff':'H','pee':'F','poop':'G',
                'eat':'E','bark':'I','fetch':'L','hurt':'J','sit':'A','tired':'K'}
COUNTS = {'idle':8,'walk':8,'run':8,'sniff':2,'pee':8,'poop':8,
          'eat':8,'bark':2,'fetch':4,'hurt':2,'sit':8,'tired':2}
COSTUME_KEYS = {'normal':'santina','armoured':'santinaKnight'}


def visible_digest(image, crop=False):
    image = image.convert('RGBA')
    if crop:
        bbox = image.getchannel('A').getbbox()
        assert bbox, 'Empty image cannot be fingerprinted'
        image = image.crop(bbox)
    data = np.asarray(image).copy()
    data[data[:,:,3] == 0] = 0
    return sha256(str(image.size).encode() + data.tobytes()).hexdigest()


def inspect_frame(frame, location):
    data = np.asarray(frame.convert('RGBA'))
    mask = data[:,:,3] > 0
    assert set(np.unique(data[:,:,3])).issubset({0,255}), (location, 'nonbinary alpha')
    assert not data[~mask,:3].any(), (location, 'hidden RGB in transparent pixels')
    assert mask.any(), (location, 'empty frame')
    assert not (mask[0,:].any() or mask[-1,:].any() or mask[:,0].any() or mask[:,-1].any()), (location, 'touches frame edge')
    bbox = frame.getchannel('A').getbbox()
    assert bbox[2] - bbox[0] >= 4 and bbox[3] - bbox[1] >= 4, (location, 'tiny/malformed frame', bbox)
    assert mask.sum() < mask.size * .85, (location, 'background filled or malformed alpha')
    opaque = data[mask]
    # These statistics support identity review; cream fur and teal shadows support the visual identity review; eye concealment is checked visually.
    cream = (opaque[:,0] > 205) & (opaque[:,1] > 200) & (opaque[:,2] > 155)
    red = ((opaque[:,0] > 95) & (opaque[:,1] < 95) & (opaque[:,2] >= 25) & (opaque[:,2] < 90)
           & (opaque[:,1] <= opaque[:,2]*1.35+8) & (opaque[:,0] > opaque[:,1]*1.75)
           & (opaque[:,0] > opaque[:,2]*1.65))
    red_map = np.zeros(mask.shape, dtype=bool)
    red_map[mask] = red
    body_top = bbox[1] + round((bbox[3]-bbox[1])*.46)
    body_bottom = bbox[3] - round((bbox[3]-bbox[1])*.09)
    # The bow is also red; only torso red can establish cross preservation.
    body_red = int(red_map[body_top:body_bottom].sum())
    head_red = int(red_map[:body_top].sum())
    return {'bbox':list(bbox), 'visible_pixels':int(mask.sum()),
            'cream_pixels':int(cream.sum()), 'dark_red_pixels':int(red.sum()),
            'torso_cross_red_pixels':body_red, 'head_bow_red_pixels':head_red}


class SavedFiles:
    def __init__(self, output, integration, costume):
        self.folder = output / costume
        self.integration = integration / costume
        self.names = [p.name for p in (self.folder/'sheets').glob('*.png')]
    def metadata(self, key):
        return json.loads((self.integration/f'{key}-atlas-layout.json').read_text())
    def native_bytes(self, name):
        return (self.folder/'game/public/sprites'/name).read_bytes()
    def sheet_bytes(self, code):
        matches = [n for n in self.names if n.startswith(code+'_')]
        assert len(matches) == 1, (code, matches)
        return (self.folder/'sheets'/matches[0]).read_bytes()


class ArchiveFiles:
    def __init__(self, archive, costume):
        self.archive_path = archive
        self.archive = ZipFile(archive)
        assert self.archive.testzip() is None, 'ZIP CRC failure'
        self.names = self.archive.namelist()
        assert len(self.names) == len(set(self.names)), 'Duplicate ZIP entry names'
        self.costume = costume
    def one(self, predicate):
        matches = [n for n in self.names if predicate(n)]
        assert len(matches) == 1, matches
        return self.archive.read(matches[0])
    def metadata(self, key):
        return json.loads(self.one(lambda n:n.endswith(f'integration/{self.costume}/{key}-atlas-layout.json')))
    def native_bytes(self, name):
        return self.one(lambda n:n.endswith(f'game/public/sprites/{name}'))
    def sheet_bytes(self, code):
        return self.one(lambda n:'/sheets/' in n and Path(n).name.startswith(code+'_') and n.endswith('.png'))


def decode(data):
    return Image.open(BytesIO(data)).convert('RGBA')


def audit(reader, costume):
    key = COSTUME_KEYS[costume]
    metadata = reader.metadata(key)
    assert metadata['direction_rows'] == list(DIRS)
    assert metadata['frame_size_px'] == [40,40]
    assert metadata['anchor_px'] == [20,36]
    assert list(metadata['actions']) == list(ACTION_CODES)
    atlas_bytes = reader.native_bytes(key+'.png')
    tired_bytes = reader.native_bytes(key+'-tired.png')
    atlas, tired = decode(atlas_bytes), decode(tired_bytes)
    assert atlas.size == (320,3520), atlas.size
    assert tired.size == (80,320), tired.size
    report = {'character':'Santina','costume':costume,'result':'passed',
        'direction_rows':list(DIRS),'native_main_sha256':sha256(atlas_bytes).hexdigest(),
        'native_tired_sha256':sha256(tired_bytes).hexdigest(),
        'checks':'Visible RGBA and cropped visible-pixel hashes, saved dimensions, per-frame occupancy and unclipped edges, animation changes, unused-column transparency, native frame counts and direction order.',
        'semantic_orientation_review':'Separate visual review required for rear/front three-quarter body yaw; distinct pixels alone do not prove orientation.',
        'actions':{}}
    total, next_row = 0, 0
    for action, code in ACTION_CODES.items():
        entry = metadata['actions'][action]
        count = COUNTS[action]
        assert entry['frames'] == count
        assert entry['first_row'] == (0 if action=='tired' else next_row)
        if action != 'tired':
            next_row += 8
        native_image = tired if action=='tired' else atlas
        sheet_bytes = reader.sheet_bytes(code)
        sheet = decode(sheet_bytes)
        assert sheet.size == (2048,2048), (costume,action,sheet.size)
        native_tracks, native_crops, native_stats = {}, {}, {}
        large_tracks, large_crops, large_stats = {}, {}, {}
        for row,direction in enumerate(DIRS):
            y = (entry['first_row']+row)*40
            frames = [native_image.crop((index*40,y,(index+1)*40,y+40)) for index in range(count)]
            stats = [inspect_frame(frame,(costume,'native',action,direction,index)) for index,frame in enumerate(frames)]
            fingerprints = [visible_digest(frame) for frame in frames]
            assert len(set(fingerprints)) >= 2, (costume,action,direction,'static native track')
            native_tracks[direction] = fingerprints
            native_crops[direction] = [visible_digest(frame,crop=True) for frame in frames]
            native_stats[direction] = stats
            total += count
            unused = native_image.crop((count*40,y,native_image.width,y+40))
            assert unused.getchannel('A').getbbox() is None, (costume,action,direction,'unused native cells not transparent')
            large_frames = [sheet.crop((index*256,row*256,(index+1)*256,(row+1)*256)) for index in range(8)]
            large_stats[direction] = [inspect_frame(frame,(costume,'large',action,direction,index)) for index,frame in enumerate(large_frames)]
            large_tracks[direction] = [visible_digest(frame) for frame in large_frames]
            large_crops[direction] = [visible_digest(frame,crop=True) for frame in large_frames]
            assert len(set(large_tracks[direction])) >= 2, (costume,action,direction,'static large track')
        native_unique = [len({native_tracks[d][i] for d in DIRS}) for i in range(count)]
        native_cropped_unique = [len({native_crops[d][i] for d in DIRS}) for i in range(count)]
        large_unique = [len({large_tracks[d][i] for d in DIRS}) for i in range(8)]
        large_cropped_unique = [len({large_crops[d][i] for d in DIRS}) for i in range(8)]
        assert min(native_unique) == 8, (costume,action,'native direction alias',native_unique)
        assert min(native_cropped_unique) == 8, (costume,action,'native translation-only direction alias',native_cropped_unique)
        assert min(large_unique) == 8, (costume,action,'large direction alias',large_unique)
        assert min(large_cropped_unique) == 8, (costume,action,'large translation-only direction alias',large_cropped_unique)
        item = {'native_frames_per_direction':count,
            'native_unique_facings_per_frame':native_unique,
            'native_unique_cropped_facings_per_frame':native_cropped_unique,
            'large_unique_facings_per_frame':large_unique,
            'large_unique_cropped_facings_per_frame':large_cropped_unique,
            'large_sheet_sha256':sha256(sheet_bytes).hexdigest(),
            'native_frame_statistics':native_stats,
            'large_frame_statistics':large_stats}
        if action in ('idle','sit'):
            planted = {}
            for row,direction in enumerate(DIRS):
                frames = [sheet.crop((i*256,row*256,(i+1)*256,(row+1)*256)) for i in range(8)]
                # Last visible paw band: breathing may move the upper silhouette only.
                bottom = max(frame.getchannel('A').getbbox()[3] for frame in frames)
                band_start = max(0,bottom-12)
                band_hashes = [visible_digest(frame.crop((0,band_start,256,bottom))) for frame in frames]
                planted[direction] = len(set(band_hashes)) == 1
            item['grounded_idle_paw_band_stable'] = planted
            assert all(planted.values()), (costume,action,'idle paw band changed',planted)
        if costume == 'armoured':
            counts={d:[s['torso_cross_red_pixels'] for s in native_stats[d]] for d in ('N','NE','NW')}
            explicit=metadata.get('native_cross_regions',{}).get(action,{})
            for direction,box in explicit.items():
                row=DIRS.index(direction)
                y=(entry['first_row']+row)*40
                values=[]
                for index in range(count):
                    cell=np.asarray(native_image.crop((index*40,y,(index+1)*40,y+40))).astype(int)
                    rr,gg,bb,aa=[cell[:,:,i] for i in range(4)]
                    mask=(aa>0)&(rr>95)&(gg<95)&(bb>=25)&(bb<90)&(gg<=bb*1.35+8)&(rr>gg*1.75)&(rr>bb*1.65)
                    left,top,right,bottom=box
                    values.append(int(mask[top:bottom,left:right].sum()))
                counts[direction]=values
            item['native_rear_dark_red_pixels'] = counts
            item['explicit_native_cross_regions'] = explicit or None
            assert all(n > 0 for values in item['native_rear_dark_red_pixels'].values() for n in values), (costume,action,'native rear cross red lost')
        report['actions'][action] = item
    assert next_row == 88 and total == 544, (next_row,total)
    report['native_populated_frames'] = total
    report['large_exported_frames'] = 768
    return report


def main():
    base = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=base/'output')
    parser.add_argument('--integration',type=Path,default=base/'integration')
    parser.add_argument('--costume',choices=list(COSTUME_KEYS))
    parser.add_argument('--zip',type=Path,help='Audit the bytes inside this final ZIP; requires --costume')
    parser.add_argument('--report',type=Path)
    args = parser.parse_args()
    costumes = [args.costume] if args.costume else list(COSTUME_KEYS)
    assert not args.zip or args.costume, '--zip requires --costume'
    summaries=[]
    for costume in costumes:
        reader = ArchiveFiles(args.zip,costume) if args.zip else SavedFiles(args.output,args.integration,costume)
        report = audit(reader,costume)
        if args.zip:
            report['archive'] = args.zip.name
            report['archive_size_bytes'] = args.zip.stat().st_size
            report['archive_sha256'] = sha256(args.zip.read_bytes()).hexdigest()
            assert report['archive_size_bytes'] < 24_000_000, 'Archive exceeds the requested upload budget'
            destination = args.report or base/'qa'/(costume+'-final-zip-audit.json')
        else:
            destination = args.report or args.integration/costume/'EIGHT_DIRECTION_PIXEL_CHECKS.json'
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(json.dumps(report,indent=2)+'\n')
        if not args.zip:
            checks_path=args.integration/costume/'INTEGRATION_CHECKS.json'
            checks=json.loads(checks_path.read_text()) if checks_path.exists() else {}
            checks['eight_direction_pixel_validation']={
                'saved_png_pixel_audit':'passed; see EIGHT_DIRECTION_PIXEL_CHECKS.json',
                'native_unique_facings_per_frame':8,
                'large_unique_facings_per_frame':8,
                'translation_only_alias_check':'passed',
                'all_frame_edges_unclipped':True,
                'native_populated_frames':544,
                'large_exported_frames':768}
            if 'eight_direction_revision' in checks:
                checks['eight_direction_revision']['saved_png_pixel_audit'] = 'passed; see EIGHT_DIRECTION_PIXEL_CHECKS.json'
            checks_path.write_text(json.dumps(checks,indent=2)+'\n')
        summaries.append({'costume':costume,'result':report['result'],'native_frames':544,'large_frames':768,
                          'all_frames_have_distinct_eight_facings':True,'report':str(destination)})
    print(json.dumps(summaries,indent=2))


if __name__=='__main__':
    main()
