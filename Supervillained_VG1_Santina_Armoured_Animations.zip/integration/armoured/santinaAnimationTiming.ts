/** Shared by the normal and knight Santina definitions. Copy to src/assets/. */
import type { AnimDef, AnimName, CharacterDef } from './manifest';

function timed(frameDurationsMs: readonly number[], loop = true): AnimDef {
  const frames = frameDurationsMs.length;
  const durationMs = frameDurationsMs.reduce((total, hold) => total + hold, 0);
  return { frames, fps: frames * 1000 / durationMs, loop, frameDurationsMs };
}

/** Insertion order is the main-atlas action row order. Tired uses its own sheet. */
export const SANTINA_ANIMS = {
  idle: timed([100, 110, 120, 110, 100, 110, 120, 110]),
  walk: timed([90, 80, 90, 110, 90, 80, 90, 110]),
  run: timed([50, 60, 60, 50, 60, 50, 50, 50]),
  sniff: { frames: 2, fps: 5, loop: true },
  pee: timed([120, 100, 130, 250, 360, 280, 140, 180], false),
  poop: timed([120, 130, 150, 220, 360, 220, 140, 180], false),
  eat: timed([110, 100, 100, 90, 180, 90, 90, 120]),
  bark: { frames: 2, fps: 10, loop: false },
  fetch: { frames: 4, fps: 13, loop: false },
  hurt: { frames: 2, fps: 10, loop: false },
  sit: timed([120, 120, 150, 120, 120, 120, 150, 120]),
  tired: { frames: 2, fps: 4, loop: true },
} satisfies Partial<Record<AnimName, AnimDef>>;

/** Paths are relative to the game's public/ directory. Each costume loads independently. */
export function makeSantinaDefinition(key: string, basename: string): CharacterDef {
  return {
    key,
    frameW: 40,
    frameH: 40,
    anchorX: 20,
    anchorY: 36,
    sheet: `sprites/${basename}.png`,
    animSheets: { tired: `sprites/${basename}-tired.png` },
    anims: SANTINA_ANIMS,
  };
}
