/** Copy to src/assets/santinaKnightCharacter.ts. See README_PIXIJS.md. */
import { makeSantinaDefinition } from './santinaAnimationTiming';

export const SANTINA_KNIGHT_CHARACTER = makeSantinaDefinition('santinaKnight', 'santinaKnight');
