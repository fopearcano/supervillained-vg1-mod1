# Santina — armoured animation integration

This delivery targets `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`, checked on 26 November 2026 at commit `95b69c04c5c3b9626e49719f8f916a44659cd265`. The branch, manifest and cast fallback were freshly read. The repository uses PixiJS 8 / TypeScript / Vite / Capacitor. Its existing normal `santina` entry points to `sprites/pixel-cast/santina.png` and has the older five-action layout. No `santinaKnight` entry existed at verification.

Santina is the supplied cream-white Maltese with teal fur shadows. Her long forehead fringe physically conceals BOTH eyes in every pose: no visible eyeballs, pupils, irises or eyelids. One red bow stays on her PHYSICAL LEFT temple, image-right in front and image-left from behind. It is prominent in W/SW/NW and can be hidden on the far side in E/NE/SE. Never mirror the bow simply to make it visible. F uses a female dog's shallow urination squat; G is deeper. I is barking and K tired panting. There is no ball or other separate prop.

## Install

1. Copy `game/public/sprites/santinaKnight.png` and `santinaKnight-tired.png` into the repository's `public/sprites/`.
2. Copy `integration/armoured/santinaKnightCharacter.ts` and `santinaAnimationTiming.ts` into `src/assets/`.
3. In `src/assets/manifest.ts`, import the definition and put the override **after** `...castDefs(CAST_KEYS)`:

```ts
import { SANTINA_KNIGHT_CHARACTER } from './santinaKnightCharacter';

// At the end of CHARACTERS:
  ...castDefs(CAST_KEYS),
  santinaKnight: SANTINA_KNIGHT_CHARACTER,
```

Add `'santinaKnight'` alongside the existing `'santina'` entry in `CAST_KEYS`. Preserve the user's other character overrides. Installing this costume does not require the other Santina ZIP. If installing both, retain both character overrides and one copy of the identical `santinaAnimationTiming.ts`.

4. For a compatible emergency Maltese fallback if its PNG fails to load, add this assignment after the `CAST_SPECS` object in `src/assets/placeholders/cast.ts`, before characters are built:

```ts
CAST_SPECS.santinaKnight = {
  ...CAST_SPECS.santina!,
  colors: {
    ...CAST_SPECS.santina!.colors,
    base: '#fff8e6', shade: '#91c7bd', deep: '#438d8c',
    outline: '#02282a', eye: '#fff8e6', nose: '#033b40',
  },
  stripes: undefined, muzzle: undefined, eyes: undefined, marks: undefined,
  fluffy: true, ears: 'floppy', tail: 'fluff',
  costume: "tabard",
  hat: "helm",
  hatColor: "#99919a",
};
```

The inspected fallback type is `Record<string, CritterSpec>`. This uses the existing Maltese anatomy, ivory/teal colours and cream eye ink. The generic emergency renderer does not reproduce the delivered long fringe or the precise bow attachment; use the loaded PNGs for visual acceptance, and fix paths if a generic placeholder appears. Loaded PNGs supply the fully eye-concealing hair and detailed bow/armour. Choose `santinaKnight` for scenes requiring armour; existing `santina` actors retain their normal costume. No story or playable roster changes are required by installation.

## Atlas layout

The native main atlas is 320 × 3520 pixels, with 40 × 40 cells and anchor `(20,36)`. Tired is a separate 80 × 320 atlas. Preserve action insertion order in the timing module. The actual loader skips tired in the main sheet because tired has an `animSheets` path.

| Row | Body projection |
| --- | --- |
| N | Back, directly away |
| NE | Rear-right quarter |
| E | Right profile |
| SE | Front-right quarter |
| S | Front |
| SW | Front-left quarter |
| W | Left profile |
| NW | Rear-left quarter |

All eight are separately drawn body facings. Keep NE/E/SE and NW/W/SW distinct. Rear quarters show the back/rump and turn away; front quarters show face/chest. The armoured red cross belongs on the back and is visible in N/NE/NW.

The twelve large sheets are 2048 × 2048, with eight 256 × 256 frame columns and the same eight direction rows. Four generated key poses per facing supply the large cycles, expanded with authored holds and small body offsets. The two idles use a stable pose with planted-paw breathing. Movement cycles run in place. No separate feeding/fetching prop is included.

| Native key | Large sheet / visible action | Frames per facing |
| --- | --- | --- |
| idle | B standing | 8 |
| walk | C walking | 8 |
| run | D running | 8 |
| sniff | H sniffing | 2 |
| pee | F female dog urination squat | 8 |
| poop | G deeper rear squat | 8 |
| eat | E drinking/eating | 8 |
| bark | I barking | 2 |
| fetch | L pounce | 4 |
| hurt | J flinch | 2 |
| sit | A seated idle | 8 |
| tired | K tired panting | 2, separate sheet |

Unused native columns are transparent. Preserve nearest-neighbour sampling. Read `animations.json` for large-sheet frame holds and the integration atlas JSON for native slicing.

## Play actions and verify

The inspected `Actor` selects walk/run while moving, standing idle on stopping, and seated idle after three seconds. Scene actions use its existing API:

```ts
santinaActor.playAction('sniff');
santinaActor.playAction('eat', 1.5);
santinaActor.playAction('pee');
santinaActor.playAction('poop');
santinaActor.playAction('bark');
santinaActor.playAction('hurt');
santinaActor.playAction('fetch');
santinaActor.playAction('tired', 2);
```

The actor pauses movement for gestures and resumes its behaviour afterwards. Pee, poop, bark, hurt and fetch are one-shots; eating, sniffing and tired loop for the requested duration. Sound is separate from these PNG visual clips.

After merging, run `npm run build` and `npm test`, then inspect `?debug=sprites&char=santinaKnight`. Check all twelve actions and eight facings, breathing with grounded paws, female squat, fully eye-concealing fringe and physical-left bow. Run `npm run android:sync` before rebuilding Android.

Delivery checks cover saved PNG pixels, slicing/timing definitions, and the original repository loader exercised with mocked textures. They do not claim a complete game build or an in-game playtest.
