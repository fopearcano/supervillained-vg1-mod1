# Jack — normal animation integration

This delivery targets `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`. The branch, manifest and placeholder definitions were checked on 25 November 2026 at commit `95b69c04c5c3b9626e49719f8f916a44659cd265`. It is a PixiJS 8 / TypeScript game with Capacitor targets. Its existing normal `jack` key uses the older five-action `sprites/pixel-cast/jack.png` sheet.

This archive supplies Jack's complete twelve-action normal set. It can be installed independently of the armoured archive.

## Install

1. Copy `game/public/sprites/jack.png` and `jack-tired.png` into the repository's `public/sprites/` directory.
2. Copy `integration/normal/jackCharacter.ts` and `jackAnimationTiming.ts` into `src/assets/`.
3. In `src/assets/manifest.ts`, add the import below and place the character override **after** `...castDefs(CAST_KEYS)`:

```ts
import { JACK_CHARACTER } from './jackCharacter';

// At the end of CHARACTERS:
  ...castDefs(CAST_KEYS),
  jack: JACK_CHARACTER,
```

`jack` is already in `CAST_KEYS`. The override replaces both the old sprite path and its five-action layout. Existing story actors using `jack` then load this complete set. Keep existing overrides for other delivered characters.

If installing both Jack archives, keep one copy of `jackAnimationTiming.ts`; the copies are identical. Each costume uses its own two PNGs and does not require the other costume's artwork.

## Atlas layout

Native frames are 40 × 40 pixels, with anchor `(20, 36)`. The main atlas is 320 × 3520 pixels; the separate tired atlas is 80 × 320. Each main action occupies eight direction rows. Preserve the action insertion order in `jackAnimationTiming.ts`; the loader skips `tired` in the main sheet because it has an `animSheets` entry.

| Facing row | Drawn projection |
| --- | --- |
| N | Back |
| NE | Rear-right three-quarter |
| E | Right profile |
| SE | Front-right three-quarter |
| S | Front |
| SW | Front-left three-quarter |
| W | Left profile |
| NW | Rear-left three-quarter |

Every action has separately drawn rear and front diagonal projections. Preserve all eight rows when importing. NE/E/SE and NW/W/SW must remain different facings.

The large sheets contain eight 256 × 256 frames per row on a 2048 × 2048 transparent canvas. They use the same eight-direction order. Read the corresponding `animations.json` for the frame holds. Four drawn key poses supply the action cycle; timing holds and subtle breathing/bob offsets produce eight exported frames. Both seated and standing idles preserve the grounded feet while breathing.

| Native action | Large sheet | Native frames per facing |
| --- | --- | --- |
| idle | B — standing | 8 |
| walk | C — walking | 8 |
| run | D — running | 8 |
| sniff | H — sniffing | 2 |
| pee | F — peeing | 8 |
| poop | G — pooping | 8 |
| eat | E — drinking-eating | 8 |
| bark | I — barking | 2 |
| fetch | L — fetching/pounce | 4 |
| hurt | J — hurt/flinch | 2 |
| sit | A — stand-sitting | 8 |
| tired | K — tired/panting | 2, separate sheet |

The native two-frame gestures use selected phases from their large sheets; fetching uses four phases. Unused native columns are transparent. Use nearest-neighbour sampling, particularly for Jack's yellow eyes, pink ears and black coat.

## Actor behavior

The inspected `Actor` already selects walking/running while moving, standing idle when stopping, and seated idle after three seconds. For scene gestures, use the existing API:

```ts
jackActor.playAction('sniff');
jackActor.playAction('eat', 1.5);
jackActor.playAction('pee');
jackActor.playAction('poop');
jackActor.playAction('bark');
jackActor.playAction('hurt');
jackActor.playAction('fetch');
jackActor.playAction('tired', 2);
```

The method pauses movement during the gesture and resumes the actor's behavior afterward. `pee`, `poop`, `bark`, `hurt` and `fetch` play once. Eating, sniffing and tired clips loop for the requested duration. Without a duration, the method uses one native clip cycle.

## Verify the merge

Run `npm run build` and `npm test`. Open `?debug=sprites&char=jack` in the running game and inspect all twelve actions and all eight facings. Check that the rear diagonals face away, the front diagonals show the face/chest, both idles breathe with grounded feet, and walk/run show leg motion. For Android, run `npm run android:sync` before rebuilding the APK.

The supplied checks cover TypeScript definition syntax, timing/atlas metadata and exported PNG pixels. A complete game build and in-game playback were not run as part of this asset delivery.
