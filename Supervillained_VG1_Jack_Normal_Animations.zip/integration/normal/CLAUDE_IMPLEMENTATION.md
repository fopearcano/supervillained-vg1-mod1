# Claude — implement normal Jack animations

Work in `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`. This delivery was checked against commit `95b69c04c5c3b9626e49719f8f916a44659cd265`.

1. Read `integration/normal/README_PIXIJS.md`. Inspect the current branch and preserve the user's other edits.
2. Copy `game/public/sprites/jack.png` and `jack-tired.png` to `public/sprites/`.
3. Copy `integration/normal/jackCharacter.ts` and `jackAnimationTiming.ts` to `src/assets/`.
4. Import `JACK_CHARACTER` in `src/assets/manifest.ts`. Add `jack: JACK_CHARACTER` AFTER `...castDefs(CAST_KEYS)` in `CHARACTERS`, so generated cast entries cannot overwrite the full definition.
5. The normal `jack` key is already in `CAST_KEYS`. Replace the old pixel-cast path and its five-action animation definition together.
6. Keep the authored action insertion order, timings and separate tired sheet. Keep 40 × 40 native frames, anchor `(20, 36)` and nearest-neighbour sampling.
7. Preserve eight distinct facings in row order N/NE/E/SE/S/SW/W/NW. Rear diagonals face away; front diagonals show face and chest. Do not collapse diagonal rows into profile rows. The 2048 × 2048 large sheets use the same direction order.
8. Use existing `Actor.playAction()` where a scene calls for gestures. Current movement logic already plays standing idle then seated idle after three seconds. Do not change story progression or the playable roster for an asset installation.
9. Run `npm run build` and `npm test`. Preview `?debug=sprites&char=jack` and inspect twelve actions, all eight facings, grounded breathing idles and leg motion. Run `npm run android:sync` before rebuilding Android.

This archive is independently usable. The delivery's checks cover definition syntax, timing/atlas metadata and exported PNG pixels. Validate the full game after merging; a full game build was not run during this asset delivery.
