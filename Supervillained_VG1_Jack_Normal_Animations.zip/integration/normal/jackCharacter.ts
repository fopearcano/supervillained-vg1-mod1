/** Copy to src/assets/jackCharacter.ts. See README_PIXIJS.md. */
import { makeJackDefinition } from './jackAnimationTiming';

export const JACK_CHARACTER = makeJackDefinition('jack', 'jack');
