# Claude — implement armoured Watson animations

Work in `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`. The animation delivery was prepared against commit `95b69c04c5c3b9626e49719f8f916a44659cd265`.

1. Read `integration/armoured/README_PIXIJS.md`. Inspect the current branch before merging; preserve the user's other edits.
2. Copy `game/public/sprites/watsonKnight.png` and `watsonKnight-tired.png` into the game's `public/sprites/` directory.
3. Copy `integration/armoured/watsonKnightCharacter.ts` and `watsonAnimationTiming.ts` into `src/assets/`. The timing file is identical in both Watson archives.
4. Add `'watsonKnight'` to `CAST_KEYS` in `src/assets/manifest.ts`. Import `WATSON_KNIGHT_CHARACTER`, then add `watsonKnight: WATSON_KNIGHT_CHARACTER` AFTER `...castDefs(CAST_KEYS)` in `CHARACTERS`. Keep a normal Watson override if the normal package is installed too.
5. Add the `CAST_SPECS.watsonKnight` fallback from the README in `src/assets/placeholders/cast.ts`. It keeps missing-art loading from crashing; the delivered PNG is the primary costume artwork.
6. Keep the authored action insertion order and separate `tired` sheet. The files contain the complete frame counts and authored timings. Select the `watsonKnight` key in a scene that calls for armour, without automatically rewriting campaign or player-roster choices.
7. Existing `Actor` logic already selects standing idle, then seated idle after three seconds, and supports `playAction()`. Use that API for the new gestures. Keep nearest-neighbour sampling and native anchor `(20, 36)`.
8. Run `npm run build` and `npm test`. Preview `?debug=sprites&char=watsonKnight`, inspect all twelve actions and eight native direction slots, both moving idles, exposed pink eyes, and the rear red cross. Diagonals reuse left/right profiles; the large sheets also contain an overhead view.

This armoured archive is independently usable. The new normal archive is optional. The delivery's validation report covers the supplied definition syntax, timing and atlas metadata; validate the full game after merging.
