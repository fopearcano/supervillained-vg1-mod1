# Watson — armoured animation integration

The referenced `claude/gallant-pascal-wjy5l2` branch was read at commit `95b69c04c5c3b9626e49719f8f916a44659cd265` on 25 November 2026. It is a PixiJS 8 / TypeScript game with Capacitor targets. It currently has the normal `watson` key and no `watsonKnight` key. This package adds the twelve-action armoured Watson costume and can be installed independently of the new normal package.

## Files

Copy the contents of `game/public/sprites/` into the repository's `public/sprites/` directory. Copy these two TypeScript files into `src/assets/`:

- `integration/armoured/watsonAnimationTiming.ts`
- `integration/armoured/watsonKnightCharacter.ts`

The shared timing file is identical in both Watson packages. Keep a single copy if installing both.

## Manifest merge

In `src/assets/manifest.ts`, import:

```ts
import { WATSON_KNIGHT_CHARACTER } from './watsonKnightCharacter';
```

Add `'watsonKnight'` to `CAST_KEYS` alongside `'watson'`. This makes the new costume a recognized `CharacterKey`.

At the end of the `CHARACTERS` object, immediately after `...castDefs(CAST_KEYS)`, add:

```ts
  ...castDefs(CAST_KEYS),
  watsonKnight: WATSON_KNIGHT_CHARACTER,
```

The override must follow the generated cast entries. If the normal package is also installed, keep its `watson: WATSON_CHARACTER` override alongside this one. The two definitions load independently.

Add a fallback after the existing `CAST_SPECS` object in `src/assets/placeholders/cast.ts`, before any scene can load:

```ts
CAST_SPECS.watsonKnight = {
  ...CAST_SPECS.watson!,
  colors: { ...CAST_SPECS.watson!.colors },
  costume: 'tabard',
  hat: 'helm',
  hatColor: '#99959a',
};
```

This fallback is used only when the delivered PNG cannot be loaded. The normal path uses `sprites/watsonKnight.png` plus `sprites/watsonKnight-tired.png`.

## Using the costume

Choose `watsonKnight` for a Watson actor in a scene that calls for armour. Existing `watson` actors keep their normal key until the scene chooses the costume. The new artwork does not require automatic changes to chapter progression or the playable-character roster.

Current `Actor` behavior already selects standing idle when movement stops and seated idle after three seconds. `Actor.playAction()` supports the new gestures:

```ts
watsonActor.playAction('sniff');
watsonActor.playAction('eat', 1.5);
watsonActor.playAction('pee');
watsonActor.playAction('poop');
watsonActor.playAction('bark');
watsonActor.playAction('hurt');
watsonActor.playAction('fetch');
watsonActor.playAction('tired', 2);
```

The current method pauses the actor during the action and resumes its behavior afterward. `pee`, `poop`, `bark`, `hurt` and `fetch` use non-looping native clips. Eating, sniffing and tired clips loop for the requested duration. Without a duration, `playAction()` uses one native clip cycle.

## Atlas layout

Frames are 40 × 40 pixels with anchor `(20, 36)`. The main atlas is 320 × 3520; tired is 80 × 320. Direction rows are `N, NE, E, SE, S, SW, W, NW` for each action:

| Native facing | Drawn source |
| --- | --- |
| N | Back |
| NE, E, SE | Right profile |
| S | Front |
| SW, W, NW | Left profile |

Diagonal slots reuse the side profiles. The separate overhead view is supplied in the large sheets. The main action order and counts are specified in `watsonAnimationTiming.ts` and `watsonKnight-atlas-layout.json`. Keep that insertion order; the loader advances eight rows per main-atlas action and skips `tired` because it is an `animSheets` entry.

## Verification after merging

Run `npm run build` and `npm test`. Open `?debug=sprites&char=watsonKnight` in the running game and inspect all twelve action rows, the exposed pink eyes, and rear red cross. The current debug viewer shows all eight native facings. Use nearest-neighbour texture sampling. For Android, run `npm run android:sync` before rebuilding the APK.

These are integration files and instructions for the inspected project revision. The complete game is not included in this animation archive, and a full-game build was not run as part of this asset delivery.
