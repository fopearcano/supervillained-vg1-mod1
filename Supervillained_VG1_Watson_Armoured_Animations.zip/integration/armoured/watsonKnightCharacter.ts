/** Copy to src/assets/watsonKnightCharacter.ts. See README_PIXIJS.md. */
import { makeWatsonDefinition } from './watsonAnimationTiming';

export const WATSON_KNIGHT_CHARACTER = makeWatsonDefinition('watsonKnight', 'watsonKnight');
