# Confusione — normal animation integration

This delivery targets `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`, checked on 26 November 2026 at commit `95b69c04c5c3b9626e49719f8f916a44659cd265`. The branch, manifest and cast fallback were freshly read. The repository uses PixiJS 8 / TypeScript / Vite / Capacitor. Its existing normal `confusione` entry points to `sprites/pixel-cast/confusione.png` and has the older five-action layout. No `confusioneKnight` entry existed at verification.

Confusione is the supplied grumpy orange tabby cat. These are feline poses: F uses a urination crouch, G a deeper rear squat, I meows/hisses, K breathes/yawns, and L pounces. The existing runtime key `bark` is retained for the I visual clip so other characters and engine action types do not need to change.

## Install

1. Copy `game/public/sprites/confusione.png` and `confusione-tired.png` into the repository's `public/sprites/`.
2. Copy `integration/normal/confusioneCharacter.ts` and `confusioneAnimationTiming.ts` into `src/assets/`.
3. In `src/assets/manifest.ts`, import the definition and put the override **after** `...castDefs(CAST_KEYS)`:

```ts
import { CONFUSIONE_CHARACTER } from './confusioneCharacter';

// At the end of CHARACTERS:
  ...castDefs(CAST_KEYS),
  confusione: CONFUSIONE_CHARACTER,
```

`confusione` already exists in `CAST_KEYS`. Preserve the user's other character overrides. Installing this costume does not require the other Confusione ZIP. If installing both, retain both character overrides and one copy of the identical `confusioneAnimationTiming.ts`.

4. To match the orange reference even if its PNG fails to load, add this assignment after the `CAST_SPECS` object in `src/assets/placeholders/cast.ts`, before characters are built:

```ts
CAST_SPECS.confusione = {
  ...CAST_SPECS.confusione!,
  colors: {
    ...CAST_SPECS.confusione!.colors,
    base: '#ff9414', shade: '#cf6504', deep: '#8e3e02',
    outline: '#211208', eye: '#fff1ce', nose: '#c65e2c',
  },
  stripes: '#a64703', muzzle: '#ffe1aa', eyes: 'sleepy', marks: undefined,
  costume: undefined,
  hat: undefined,
  hatColor: '#99919a',
};
```

The inspected fallback type is `Record<string, CritterSpec>`. This uses the existing cat anatomy, recoloured orange. Loaded PNGs supply the detailed reference-matching ears, face and armour. Existing actors using `confusione` load the new complete set through the override. No story or playable roster changes are required by installation.

## Atlas layout

The native main atlas is 320 × 3520 pixels, with 40 × 40 cells and anchor `(20,36)`. Tired is a separate 80 × 320 atlas. Preserve action insertion order in the timing module. The actual loader skips tired in the main sheet because tired has an `animSheets` path.

| Row | Body projection |
| --- | --- |
| N | Back, directly away |
| NE | Rear-right quarter |
| E | Right profile |
| SE | Front-right quarter |
| S | Front |
| SW | Front-left quarter |
| W | Left profile |
| NW | Rear-left quarter |

All eight are separately drawn body facings. Keep NE/E/SE and NW/W/SW distinct. Rear quarters show the back/rump and turn away; front quarters show face/chest. The armoured red cross belongs on the back and is visible in N/NE/NW.

The twelve large sheets are 2048 × 2048, with eight 256 × 256 frame columns and the same eight direction rows. Four generated key poses per facing supply the large cycles, expanded with authored holds and small body offsets. The two idles use a stable pose with planted-paw breathing. Movement cycles run in place. No separate feeding/fetching prop is included.

| Native key | Large sheet / visible action | Frames per facing |
| --- | --- | --- |
| idle | B standing | 8 |
| walk | C walking | 8 |
| run | D running | 8 |
| sniff | H sniffing | 2 |
| pee | F feline urination crouch | 8 |
| poop | G deeper feline squat | 8 |
| eat | E drinking/eating | 8 |
| bark | I meowing/hissing | 2 |
| fetch | L pounce | 4 |
| hurt | J flinch | 2 |
| sit | A seated idle | 8 |
| tired | K breathing/yawn | 2, separate sheet |

Unused native columns are transparent. Preserve nearest-neighbour sampling. Read `animations.json` for large-sheet frame holds and the integration atlas JSON for native slicing.

## Play actions and verify

The inspected `Actor` selects walk/run while moving, standing idle on stopping, and seated idle after three seconds. Scene actions use its existing API:

```ts
confusioneActor.playAction('sniff');
confusioneActor.playAction('eat', 1.5);
confusioneActor.playAction('pee');
confusioneActor.playAction('poop');
confusioneActor.playAction('bark'); // Confusione meows/hisses visually.
confusioneActor.playAction('hurt');
confusioneActor.playAction('fetch');
confusioneActor.playAction('tired', 2);
```

The actor pauses movement for gestures and resumes its behaviour afterwards. Pee, poop, bark, hurt and fetch are one-shots; eating, sniffing and tired loop for the requested duration. Sound is separate from these PNG visual clips.

After merging, run `npm run build` and `npm test`, then inspect `?debug=sprites&char=confusione`. Check all twelve actions and eight facings, breathing with grounded paws, feline movement/crouches, and reference markings. Run `npm run android:sync` before rebuilding Android.

Delivery checks cover saved PNG pixels, slicing/timing definitions, and the original repository loader exercised with mocked textures. They do not claim a complete game build or an in-game playtest.
