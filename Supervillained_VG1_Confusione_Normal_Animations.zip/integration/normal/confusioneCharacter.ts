/** Copy to src/assets/confusioneCharacter.ts. See README_PIXIJS.md. */
import { makeConfusioneDefinition } from './confusioneAnimationTiming';

export const CONFUSIONE_CHARACTER = makeConfusioneDefinition('confusione', 'confusione');
