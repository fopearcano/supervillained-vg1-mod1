# Claude — implement normal Confusione animations

Target repository `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`; delivery interface checked at `95b69c04c5c3b9626e49719f8f916a44659cd265` on 26 November 2026.

1. Read this costume's `README_PIXIJS.md`, inspect the current branch, and preserve other user edits.
2. Copy this archive's two `confusione` native PNGs to `public/sprites/` and its two TypeScript modules to `src/assets/`.
3. Import `CONFUSIONE_CHARACTER` and add `confusione: CONFUSIONE_CHARACTER` AFTER `...castDefs(CAST_KEYS)` in `CHARACTERS`. `confusione` already exists in `CAST_KEYS`.
4. Add the orange cat fallback assignment shown in the README. Keep cat anatomy and the other costumes' overrides.
5. Preserve action order, native counts, authored holds, 40px frames, anchor `(20,36)`, and the separate tired sheet. This ZIP loads independently.
6. Preserve eight separately drawn facings N/NE/E/SE/S/SW/W/NW. Do not collapse quarter rows into profile rows. Keep the armour's red cross on the back.
7. Keep the existing `bark` runtime key for Confusione's meow/hiss animation. F uses a feline urination crouch, G a deeper squat; do not substitute dog poses or change the global action enum.
8. Use existing `Actor.playAction` for scene gestures. Do not change story progression or the playable roster for an asset installation.
9. Run `npm run build` and `npm test`, inspect `?debug=sprites&char=confusione` across all actions/directions, then run `npm run android:sync` for Android.

The delivery tests PNG pixels and loader/timing definitions with mocked textures. Validate full rendering after merge; no in-game build was run during asset production.
