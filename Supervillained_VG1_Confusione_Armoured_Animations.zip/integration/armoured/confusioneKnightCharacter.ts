/** Copy to src/assets/confusioneKnightCharacter.ts. See README_PIXIJS.md. */
import { makeConfusioneDefinition } from './confusioneAnimationTiming';

export const CONFUSIONE_KNIGHT_CHARACTER = makeConfusioneDefinition('confusioneKnight', 'confusioneKnight');
