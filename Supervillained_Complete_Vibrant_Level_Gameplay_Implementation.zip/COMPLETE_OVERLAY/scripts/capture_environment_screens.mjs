import { spawn } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { chromium } from 'playwright';

const PORT = 5203;
const OUT = 'docs/screens/environments';
const VIEWPORT = { width: 400, height: 860 };
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const captures = [
  ['1.1', 'neighborhood', 'ch01-neighborhood'],
  ['1.2', 'study', 'ch01-study'],
  ['2.1', 'jerusalem', 'ch02-jerusalem'],
  ['2.2', 'fair', 'ch02-fair'],
  ['2.3', 'road', 'ch02-road'],
  ['3.1', 'venice', 'ch03-venice'],
  ['3.2', 'lido', 'ch03-lido'],
  ['4.1', 'ship', 'ch04-ship'],
  ['5.1', 'zara', 'ch05-zara'],
  ['6.1', 'winter', 'ch06-winter'],
  ['6.3', 'island', 'ch06-island'],
  ['7.1', 'city', 'ch07-city'],
  ['7.3', 'field', 'ch07-field'],
  ['7.6', 'palace', 'ch07-palace'],
  ['7.7', 'breach', 'ch07-breach'],
  ['8.1', 'shattered', 'ch08-shattered'],
  ['8.2', 'study', 'ch08-study'],
  ['8.3', 'neighborhood', 'ch08-neighborhood'],
];

async function startServer() {
  const proc = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--port', String(PORT), '--strictPort', '--host', '127.0.0.1'], {
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: true,
  });
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('vite did not start')), 30000);
    proc.stdout.on('data', (data) => {
      if (String(data).includes('Local')) {
        clearTimeout(timer);
        resolve();
      }
    });
    proc.on('exit', (code) => reject(new Error(`vite exited ${code}`)));
  });
  return proc;
}

mkdirSync(OUT, { recursive: true });
const server = await startServer();
const browser = await chromium.launch();
try {
  for (const [story, expectedMap, label] of captures) {
    const page = await browser.newPage({ viewport: VIEWPORT, deviceScaleFactor: 2, hasTouch: true, isMobile: true });
    const errors = [];
    page.on('pageerror', (error) => errors.push(error.message));
    page.on('console', (message) => {
      if (message.type() === 'error') errors.push(message.text());
    });
    await page.goto(`http://127.0.0.1:${PORT}/?story=${story}`);
    await page.waitForFunction(() => window.__sv && window.__sv.top(), null, { timeout: 30000 });
    let actual = null;
    for (let attempt = 0; attempt < 100; attempt++) {
      actual = await page.evaluate(() => window.__sv.top().mapKey ?? null);
      if (actual === expectedMap) break;
      const skipped = await page.evaluate(() => {
        const scene = window.__sv.top();
        if (!scene.debugSkip) return false;
        scene.debugSkip();
        return true;
      });
      if (!skipped) break;
      await wait(90);
    }
    if (actual !== expectedMap) throw new Error(`${story}: expected ${expectedMap}, got ${actual}`);
    await page.evaluate(() => {
      const scene = window.__sv.top();
      if (scene.dialogue?.root) scene.dialogue.root.visible = false;
      if (scene.cards?.root) scene.cards.root.visible = false;
    });
    await wait(350);
    await page.screenshot({ path: `${OUT}/${label}.png` });
    if (errors.length) throw new Error(`${story}: ${errors.join('; ')}`);
    console.log(`${label}: ok`);
    await page.close();
  }
} finally {
  await browser.close();
  try {
    process.kill(-server.pid, 'SIGTERM');
  } catch {
    server.kill();
  }
}
process.exit();
