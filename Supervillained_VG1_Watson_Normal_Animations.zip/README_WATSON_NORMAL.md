# Watson — normal animation set

Watson's full twelve-action set, using the supplied cream-and-orange terrier reference. The sleepy pink eyes, mischievous grin, cigar, scruffy coat, spotting and fluffy tail are preserved. The normal costume retains the dark teal and red cap and the spiked collar.

This ZIP is independent of the other costume ZIP. Both can also be extracted into the same directory; their artwork and implementation notes have distinct paths.

## Contents

- `animations/watson/normal/sheets/`: twelve transparent PNG animation sheets.
- `animations/watson/normal/animations.json`: frame durations, looping flags and layout metadata.
- `game/public/sprites/watson.png`: native PixiJS atlas.
- `game/public/sprites/watson-tired.png`: separate native panting atlas.
- `integration/normal/`: character definition, shared timing module, Claude instructions and native layout details.
- `previews/`: static contact sheet and compact animation preview.
- `validation/normal/`: exported-frame checks and source provenance.

## Large animation sheets

Every sheet is 2048 × 1280 pixels, with eight columns of 256 × 256 cells and five view rows in this exact order: front, back, side-L (nose left), side-R (nose right), top (nose upward). Read frames left to right. Both idle loops visibly breathe while their paws remain planted in the ground-level views. Walking and running animate in place; the game controls world movement.

| Code | Action |
| --- | --- |
| A | Seated idle |
| B | Standing idle |
| C | Walk |
| D | Run |
| E | Drink/eat |
| F | Pee / leg lift |
| G | Poop / squat |
| H | Sniff |
| I | Bark |
| J | Hurt / flinch |
| K | Tired / pant |
| L | Fetch / pounce |

The exported eight-frame clips are assembled from four generated key poses with timed holds and small body offsets. The idle clips use a stable pose with breathing motion to keep markings and feet consistent. Bathroom actions finish by returning to standing. The supplied JSON is authoritative for frame holds and loop flags.

## Game integration

Read `integration/normal/README_PIXIJS.md` and `integration/normal/CLAUDE_IMPLEMENTATION.md`. Copy the two PNGs from `game/public/sprites/` to the repository's `public/sprites/` directory and merge the supplied character definition as described. The runtime key for this costume is `watson`.

The main native atlas is 320 × 3520 pixels, using 40 × 40 cells and ground anchor (20, 36). Its action blocks are idle, walk, run, sniff, pee, poop, eat, bark, fetch, hurt and sit. Tired uses an 80 × 320 atlas. Each action has eight facing rows: N, NE, E, SE, S, SW, W, NW. N uses back, S uses front, eastern directions use side-R, and western directions use side-L. Diagonal slots deliberately reuse the side profiles; they are not separately drawn diagonal views. Top views are available in the large sheets.

The provided definitions and instructions target the inspected PixiJS branch. They are integration files for Claude to merge; this delivery does not publish or modify the repository. Preserve the nearest-neighbour pixel sampling in the game.
