# Watson — normal animation integration

The referenced `claude/gallant-pascal-wjy5l2` branch was read at commit `95b69c04c5c3b9626e49719f8f916a44659cd265` on 25 November 2026. It is a PixiJS 8 / TypeScript game with Capacitor targets. Its existing `watson` entry uses the older five-action pixel-cast sheet. This package supplies the full twelve-action normal Watson set and can be installed independently of the armoured package.

## Files

Copy the contents of `game/public/sprites/` into the repository's `public/sprites/` directory. Copy these two TypeScript files into `src/assets/`:

- `integration/normal/watsonAnimationTiming.ts`
- `integration/normal/watsonCharacter.ts`

The shared timing file is identical in both Watson packages. Keep a single copy if installing both.

## Manifest merge

In `src/assets/manifest.ts`, add:

```ts
import { WATSON_CHARACTER } from './watsonCharacter';
```

At the end of the `CHARACTERS` object, immediately after `...castDefs(CAST_KEYS)`, add the override:

```ts
  ...castDefs(CAST_KEYS),
  watson: WATSON_CHARACTER,
```

The order matters: the override must follow the generated cast entries. The existing `watson` key is already in `CAST_KEYS`. Its current five-action animation definition must be replaced by `WATSON_CHARACTER` together with the sprite path, so atlas rows use the new twelve-action layout.

The native main atlas is `sprites/watson.png`; tired/panting is `sprites/watson-tired.png`. Existing story actors with the `watson` key use the new artwork after this merge. The old `sprites/pixel-cast/watson.png` is no longer referenced by the final character definition.

## Animation behavior

Current `Actor` behavior already supports these animations. Walking/running follows movement. Stopping plays the breathing standing idle; after three seconds it plays the seated idle. Use an existing Watson actor's `playAction()` for gestures:

```ts
watsonActor.playAction('sniff');
watsonActor.playAction('eat', 1.5);
watsonActor.playAction('pee');
watsonActor.playAction('poop');
watsonActor.playAction('bark');
watsonActor.playAction('hurt');
watsonActor.playAction('fetch');
watsonActor.playAction('tired', 2);
```

The current method pauses the actor during the action and resumes its behavior afterward. `pee`, `poop`, `bark`, `hurt` and `fetch` use non-looping native clips. Eating, sniffing and tired clips loop for the requested duration. Without a duration, `playAction()` uses one native clip cycle.

## Atlas layout

Frames are 40 × 40 pixels with anchor `(20, 36)`. The main atlas is 320 × 3520; tired is 80 × 320. Direction rows are `N, NE, E, SE, S, SW, W, NW` for each action. The five drawn views are mapped as follows:

| Native facing | Drawn source |
| --- | --- |
| N | Back |
| NE, E, SE | Right profile |
| S | Front |
| SW, W, NW | Left profile |

Diagonal slots reuse the side profiles. The separate overhead view is available in the large sheets. The main action order and frame counts are specified in `watsonAnimationTiming.ts` and `watson-atlas-layout.json`. Keep that insertion order; the loader advances eight rows per main-atlas action and skips `tired` because it is an `animSheets` entry.

## Verification after merging

Run `npm run build` and `npm test`. Open `?debug=sprites&char=watson` in the running game and inspect all twelve action rows. The current debug viewer shows all eight native facings. Use nearest-neighbour texture sampling. For Android, run `npm run android:sync` before rebuilding the APK.

These are integration files and instructions for the inspected project revision. The complete game is not included in this animation archive, and a full-game build was not run as part of this asset delivery.
