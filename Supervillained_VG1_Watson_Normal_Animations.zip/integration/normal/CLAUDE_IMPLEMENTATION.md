# Claude — implement normal Watson animations

Work in `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`. The animation delivery was prepared against commit `95b69c04c5c3b9626e49719f8f916a44659cd265`.

1. Read `integration/normal/README_PIXIJS.md`. Inspect the current branch before merging; preserve the user's other edits.
2. Copy `game/public/sprites/watson.png` and `watson-tired.png` into the game's `public/sprites/` directory.
3. Copy `integration/normal/watsonCharacter.ts` and `watsonAnimationTiming.ts` into `src/assets/`.
4. Import `WATSON_CHARACTER` in `src/assets/manifest.ts`. Add `watson: WATSON_CHARACTER` AFTER `...castDefs(CAST_KEYS)` in `CHARACTERS`, so the generated five-action cast definition is overridden. Watson is already in `CAST_KEYS`.
5. Keep the authored action insertion order and separate `tired` sheet. The files contain the complete frame counts and authored timings. Use the new native atlases for all twelve actions; the old pixel-cast Watson path must not remain the active definition.
6. Existing `Actor` logic already selects standing idle, then seated idle after three seconds, and supports `playAction()`. Use that API where a scene needs sniff/eat/pee/poop/bark/hurt/fetch/tired. Keep story choices authored by the user.
7. Keep nearest-neighbour sampling and anchor `(20, 36)` for the native 40 × 40 frames. N uses the back view; S the front; diagonal directions reuse the corresponding left/right profile. Overhead art is in the large sheets.
8. Run `npm run build` and `npm test`. Preview `?debug=sprites&char=watson`, inspect every action and all eight native direction slots, and confirm both idles move while grounded paws remain stable.

This normal archive is independently usable. The armoured archive is optional. The delivery's validation report covers the supplied definition syntax, timing and atlas metadata; validate the full game after merging.
