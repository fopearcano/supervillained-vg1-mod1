/** Copy to src/assets/watsonCharacter.ts. See README_PIXIJS.md. */
import { makeWatsonDefinition } from './watsonAnimationTiming';

export const WATSON_CHARACTER = makeWatsonDefinition('watson', 'watson');
