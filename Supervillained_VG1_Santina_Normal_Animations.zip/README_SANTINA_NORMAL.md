# Santina — normal — eight-direction animation set

Santina is the cream-white Maltese from the supplied references: teal fur shadows, long hanging ears, a black nose, smiling muzzle, fluffy paws and a curled plume tail. Her long forehead hair completely conceals both eyes in every pose. One red bow stays on her physical left temple, image-right from the front and image-left from the rear; it can be hidden on the far side in right-facing views. The armoured costume uses the supplied steel helmet, chainmail and shoulder plates, with a red cross on the back.

## Contents

- `animations/santina/normal/sheets/`: twelve transparent large animation sheets.
- `animations/santina/normal/animations.json`: sheet slicing, direction names and authored frame holds.
- `game/public/sprites/santina.png` and `santina-tired.png`: native game atlases.
- `integration/normal/`: the independent PixiJS integration definitions and instructions.
- `previews/`: an animated preview and eight-direction contact sheet.
- `validation/normal/`: saved-pixel checks, provenance and delivered PNG hashes.
- `source-notes/normal/`: the image-generation prompts used for these assets.

Each large sheet is 2048 × 2048 pixels, with eight 256 × 256 frame columns and eight direction rows. Rows are **N, NE, E, SE, S, SW, W, NW**, from top to bottom. Frames run left to right. N shows the back, S the face, E/W the profiles, NE/NW the rear quarters, and SE/SW the front quarters. Directions are separately drawn body views; raster rotation is not used to produce them.

## Actions

| Code | Action | Playback |
| --- | --- | --- |
| A | Seated idle / stand-sitting | Loop |
| B | Standing idle | Loop |
| C | Walking | Loop |
| D | Running | Loop |
| E | Drinking / eating | Loop |
| F | Peeing / female squat | Once |
| G | Pooping / deeper squat | Once |
| H | Sniffing | Loop |
| I | Barking | Once |
| J | Hurt / flinch | Once |
| K | Tired / panting | Loop |
| L | Fetching / pounce | Once |

The large sheets export eight timed frames from four generated key poses per direction. Idle breathing uses a stable pose and planted paws. Other clips use authored holds and small registration/body offsets between the drawn key poses. Walking and running play in place; the game supplies world movement. Feeding and fetching are supplied without a separate prop.

## Install

Either ZIP can be installed independently. Copy its two native PNGs into `public/sprites/` and follow `integration/normal/README_PIXIJS.md` plus `CLAUDE_IMPLEMENTATION.md`. The character key is `santina`. Normal and armoured files have distinct names and can coexist.

The native main atlas is 320 × 3520 pixels with 40 × 40 cells, eight direction rows per action, and anchor (20,36). It contains idle, walk, run, sniff, pee, poop, eat, bark, fetch, hurt and sit, in that order. Tired uses a separate 80 × 320 atlas. F uses a female dog urination squat, with paws grounded, and G uses a deeper rear squat. The I clip is barking. Keep both eyes hidden and preserve the bow's physical-left attachment in every facing. Native frame counts and timing are specified in the integration metadata. Use nearest-neighbour filtering for pixel art.

Validation covers the actual saved PNG pixels and archive entries, including populated cells, direction uniqueness, animation changes, sheet geometry and transparency. Integration definitions have been checked against the inspected repository interface; this asset delivery does not claim a completed in-game playtest.
