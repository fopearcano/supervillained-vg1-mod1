/** Copy to src/assets/santinaCharacter.ts. See README_PIXIJS.md. */
import { makeSantinaDefinition } from './santinaAnimationTiming';

export const SANTINA_CHARACTER = makeSantinaDefinition('santina', 'santina');
