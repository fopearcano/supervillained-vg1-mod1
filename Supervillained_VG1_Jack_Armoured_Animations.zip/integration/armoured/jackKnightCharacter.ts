/** Copy to src/assets/jackKnightCharacter.ts. See README_PIXIJS.md. */
import { makeJackDefinition } from './jackAnimationTiming';

export const JACK_KNIGHT_CHARACTER = makeJackDefinition('jackKnight', 'jackKnight');
