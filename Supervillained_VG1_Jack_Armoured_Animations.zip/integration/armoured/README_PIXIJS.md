# Jack — armoured animation integration

This delivery targets `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`. The branch, manifest and placeholder definitions were checked on 25 November 2026 at commit `95b69c04c5c3b9626e49719f8f916a44659cd265`. It is a PixiJS 8 / TypeScript game with Capacitor targets. It currently contains the normal `jack` key and no `jackKnight` key.

This archive supplies Jack's complete twelve-action armoured set. It can be installed independently of the new normal archive.

## Install

1. Copy `game/public/sprites/jackKnight.png` and `jackKnight-tired.png` into the repository's `public/sprites/` directory.
2. Copy `integration/armoured/jackKnightCharacter.ts` and `jackAnimationTiming.ts` into `src/assets/`.
3. In `src/assets/manifest.ts`, import the definition, add `'jackKnight'` to `CAST_KEYS` alongside `'jack'`, and place the character override **after** `...castDefs(CAST_KEYS)`:

```ts
import { JACK_KNIGHT_CHARACTER } from './jackKnightCharacter';

// In CAST_KEYS:
  'jack',
  'jackKnight',

// At the end of CHARACTERS:
  ...castDefs(CAST_KEYS),
  jackKnight: JACK_KNIGHT_CHARACTER,
```

Keep existing overrides for other delivered characters. If the normal Jack archive is also installed, keep its `jack: JACK_CHARACTER` override alongside this one. The shared `jackAnimationTiming.ts` copies are identical; keep one copy.

4. Add the following fallback after the existing `CAST_SPECS` object in `src/assets/placeholders/cast.ts`, before any scenes load:

```ts
CAST_SPECS.jackKnight = {
  ...CAST_SPECS.jack!,
  colors: {
    ...CAST_SPECS.jack!.colors,
    base: '#111214',
    shade: '#303033',
    deep: '#08090a',
    outline: '#08090a',
    eye: '#eacb28',
    nose: '#493047',
  },
  muzzle: '#fff0d5',
  costume: 'tabard',
  hat: 'helm',
  hatColor: '#99959a',
};
```

The inspected `CAST_SPECS` type is `Record<string, CritterSpec>`, so the assignment supports the new key. This fallback is used only if the delivered PNG cannot load. The normal path loads `sprites/jackKnight.png` and `sprites/jackKnight-tired.png`; it does not load the new normal Jack files.

## Choose the costume

Use `jackKnight` for a Jack actor in a scene requiring armour. Existing `jack` actors retain their normal costume until the scene chooses the new key. No chapter progression or playable-character roster changes are required by the asset installation.

## Atlas layout

Native frames are 40 × 40 pixels with anchor `(20, 36)`. The main atlas is 320 × 3520 pixels; tired is a separate 80 × 320 sheet. Each main action occupies eight direction rows. Preserve the action insertion order in `jackAnimationTiming.ts`; the loader skips `tired` in the main sheet because it has an `animSheets` entry.

| Facing row | Drawn projection |
| --- | --- |
| N | Back |
| NE | Rear-right three-quarter |
| E | Right profile |
| SE | Front-right three-quarter |
| S | Front |
| SW | Front-left three-quarter |
| W | Left profile |
| NW | Rear-left three-quarter |

Every action uses separately drawn diagonals. NE/NW show the back/rump and red back cross; SE/SW show the face/chest. Preserve all eight rows when importing. NE/E/SE and NW/W/SW must remain different facings. The red cross belongs on the back only.

The large sheets contain eight 256 × 256 frames per row on a 2048 × 2048 transparent canvas. Their direction order is identical to the native sheets; `animations.json` supplies frame holds. Four drawn key poses supply each action cycle; timing holds and breathing/bob offsets produce eight exported frames. Both idle variants keep the feet grounded.

| Native action | Large sheet | Native frames per facing |
| --- | --- | --- |
| idle | B — standing | 8 |
| walk | C — walking | 8 |
| run | D — running | 8 |
| sniff | H — sniffing | 2 |
| pee | F — peeing | 8 |
| poop | G — pooping | 8 |
| eat | E — drinking-eating | 8 |
| bark | I — barking | 2 |
| fetch | L — fetching/pounce | 4 |
| hurt | J — hurt/flinch | 2 |
| sit | A — stand-sitting | 8 |
| tired | K — tired/panting | 2, separate sheet |

The native two-frame gestures use selected phases from the large sheets; fetching uses four. Unused native columns are transparent. Use nearest-neighbour sampling to retain the yellow eyes, pink ears and red back cross.

## Actor behavior

The inspected `Actor` already selects walking/running, standing idle when stopping, and seated idle after three seconds. Its gesture API works for either costume:

```ts
jackActor.playAction('sniff');
jackActor.playAction('eat', 1.5);
jackActor.playAction('pee');
jackActor.playAction('poop');
jackActor.playAction('bark');
jackActor.playAction('hurt');
jackActor.playAction('fetch');
jackActor.playAction('tired', 2);
```

`playAction()` pauses movement and resumes behavior afterward. `pee`, `poop`, `bark`, `hurt` and `fetch` play once. Eating, sniffing and tired clips loop for the requested duration. Without a duration, the method uses one native clip cycle.

## Verify the merge

Run `npm run build` and `npm test`. Open `?debug=sprites&char=jackKnight` and inspect every action, all eight facings, the red back cross in N/NE/NW and the planted-foot idle motion. For Android, run `npm run android:sync` before rebuilding the APK.

The supplied checks cover TypeScript definition syntax, timing/atlas metadata and exported PNG pixels. A complete game build and in-game playback were not run as part of this asset delivery.
